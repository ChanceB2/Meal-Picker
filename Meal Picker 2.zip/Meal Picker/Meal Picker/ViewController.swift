//
//  ViewController.swift
//  Meal Picker
//
//  Created by Chance Burroughs on 9/21/21.
/*“this App is developed as an educational project”. If any copyrighted
 materials are included in accordance to the multimedia fair use guidelines, a notice should be added
 and states that “certain materials are included under the fair use exemption of the U.S. Copyright Law
 and have been prepared according to the multimedia fair use guidelines and are restricted from further
 use”**/
//

import UIKit
import AVKit


class ViewController: UIViewController{//, UIPickerViewDelegate, UIPickerViewDataSource{
    var currentSegment = "Fast Food"
    
    @IBOutlet weak var lblResturant: UILabel!
    @IBOutlet weak var lblResturantType: UILabel!
    @IBOutlet weak var lblFoodType: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var UIResImage: UIImageView!//Images for resturants
    @IBOutlet weak var favResturant: UISwitch!
    @IBOutlet weak var resMenuHid: UIButton!
    @IBOutlet weak var resHeartHid: UIImageView!
    
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
   
    @IBAction func indexChanged(_ sender: Any) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            currentSegment = "Fast Food"//Fast Food
            //not sure what sound to add
        case 1:
            currentSegment = "Sit Down"//Sit-Down
            //Add diner ding
        case 2:
            currentSegment = "Pizza"//Pizza
            //add pizza ready sound
        default:
            break
        }
    }
    
    var mySound:AVAudioPlayer!
    var ResObjectArray = [Restaurants]()
    var currentPickerValue = ""

    func populateRestaurants(){
        
        //Fast Foods
            var R1 = Restaurants()
            R1.name = "Taco Bell"
            R1.resType = "Fast Food"
            R1.foodType = "Mexican"
            R1.address = "11017 Nokesville Rd, Manassas, VA 20110"
            R1.picture = "TacoBell.jpeg"
            R1.menu = "https://www.tacobell.com/food"
            ResObjectArray.insert(R1, at:0)
        
            var R2 = Restaurants()
            R2.name = "Burger King"
            R2.resType = "Fast Food"
            R2.foodType = "American Burgers"
            R2.address = "8889 Centerville Rd, Manassas, VA 20110"
            R2.picture = "BurgerKing.jpeg"
            R2.menu = "https://www.bk.com/menu"
            ResObjectArray.append(R2)
        
            var R3 = Restaurants()
            R3.name = "Mcdonalds"
            R3.resType = "Fast Food"
            R3.foodType = "American Burgers"
            R3.address = "8203 Sudley Rd, Manassas, VA 20109"
            R3.picture = "Mcdonalds.jpeg"
            R3.menu = "https://www.mcdonalds.com/us/en-us/full-menu.html"
            ResObjectArray.append(R3)

        
            var R4 = Restaurants()
            R4.name = "Bojangles"
            R4.resType = "Fast Food"
            R4.foodType = "Chicken"
            R4.address = "46160 Potomac Run Plaza, Sterling, VA 20164"
            R4.picture = "Bojangles.jpeg"
            R4.menu = "https://www.bojangles.com/menu/"
            ResObjectArray.append(R4)

            var R5 = Restaurants()
            R5.name = "Chick Fil-A"
            R5.resType = "Fast Food"
            R5.foodType = "Chicken"
            R5.address = "9506 Liberia Ave, Manassas, VA 20110"
            R5.picture = "ChickFilA.jpeg"
            R5.menu = "https://www.chick-fil-a.com/menu"
            ResObjectArray.append(R5)

            var R6 = Restaurants()
            R6.name = "Arbys"
            R6.resType = "Fast Food"
            R6.foodType = "Sandwhiches"
            R6.address = "9874 Liberia Ave, Manassas, VA 20110"
            R6.picture = "Arbys.jpeg"
            R6.menu = "https://www.arbys.com/menu/"
            ResObjectArray.append(R6)
        //End of Fast Foods
            
        //Sit down
            var R7 = Restaurants()
            R7.name = "Outback SteakHouse"
            R7.resType = "Sit Down"
            R7.foodType = "Steakhouse"
            R7.address = "4995 Wellington Rd, Gainesville, VA 20155"
            R7.picture = "Outback.jpeg"
            R7.menu = "https://order.outback.com/"
            ResObjectArray.append(R7)

            var R8 = Restaurants()
            R8.name = "Red Robin"
            R8.resType = "Sit Down"
            R8.foodType = "American Burgers"
            R8.address = "9665 Liberia Ave, Manassas, VA 20111"
            R8.picture = "RedRobin.jpeg"
            R8.menu = "https://www.redrobin.com/#whats-new"
            ResObjectArray.append(R8)

            var R9 = Restaurants()
            R9.name = "Glory Days"
            R9.resType = "Sit Down"
            R9.foodType = "Sports Food"
            R9.address = "9516 Liberia Ave, Manassas, VA 20110"
            R9.picture = "GloryDays.jpeg"
            R9.menu = "https://www.glorydaysgrill.com/food/"
            ResObjectArray.append(R9)

            var R10 = Restaurants()
            R10.name = "Olive Garden"
            R10.resType = "Sit Down"
            R10.foodType = "Italian"
            R10.address = "7501 Broken Branch Ln, Manassas, VA 20109"
            R10.picture = "OliveGarden.jpeg"
            R10.menu = "https://www.olivegarden.com/"
            ResObjectArray.append(R10)

            var R11 = Restaurants()
            R11.name = "Logans Steakhouse"
            R11.resType = "Sit Down"
            R11.foodType = "Steakhouse"
            R11.address = "7731 Donegan Dr, Manassas, VA 20110"
            R11.picture = "LogansSteakhouse.jpeg"
            R11.menu = "https://logansroadhouse.com/menu"
            ResObjectArray.append(R11)

            var R12 = Restaurants()
            R12.name = "Sakura Grill Ashburn"
            R12.resType = "Sit Down"
            R12.foodType = "Hibachi"
            R12.address = "43670 Greenway Corporate Dr #112, Ashburn, VA 20147"
            R12.picture = "Sakura.jpeg"
            R12.menu = "https://www.sakuragrillashburn.com/"
            ResObjectArray.append(R12)
        //End of sit downs
        
        //Pizza Restaurants
            var R13 = Restaurants()
            R13.name = "Pizza Hut"
            R13.resType = "Pizza"
            R13.foodType = "Pizza"
            R13.address = "10060 Dumfries Rd, Manassas, VA 20110"
            R13.picture = "PizzaHut.jpeg"
            R13.menu = "https://www.pizzahut.com/"
            ResObjectArray.append(R13)
            
            var R14 = Restaurants()
            R14.name = "Paisanos"
            R14.resType = "Pizza"
            R14.foodType = "Italian"
            R14.address = "8683 Sudley Rd, Manassas, VA 20110"
            R14.picture = "Paisianos.jpg"
            R14.menu = "https://www.paisanospizza.com/menu"
            ResObjectArray.append(R14)
            
            var R15 = Restaurants()
            R15.name = "Dominoes"
            R15.resType = "Pizza"
            R15.foodType = "Pizza"
            R15.address = "10175 Hastings Dr, Manassas, VA 20110"
            R15.picture = "Dominos.jpeg"
            R15.menu = "https://www.dominos.com/en/pages/order/menu#!/menu/category/viewall/"
            ResObjectArray.append(R15)
        //End of Pizza Resaurants
        
    }
    var randomGloblaObject:Restaurants = Restaurants()

    func setLabels(){
        var randomHT = ResObjectArray.randomElement()
        while(!(randomHT!.resType == currentSegment)){
            randomHT = ResObjectArray.randomElement()
        }
        if(randomHT!.resType == currentSegment){
            randomGloblaObject = randomHT!
            lblResturant.text = randomHT?.name
            lblResturantType.text = randomHT?.resType
            lblFoodType.text = randomHT?.foodType
            lblAddress.text = randomHT?.address
            let imgName = randomHT!.picture
            UIResImage.image = UIImage(named:imgName)
            favResturant.isHidden = false
            resMenuHid.isHidden = false
            resHeartHid.isHidden = false
            mySound.play()
            var fav = UserDefaults.standard.string(forKey: "favorite")
            favResturant.isOn = (randomHT!.name == fav)
            randomHT!.isFav = (randomHT!.name == fav)
        }
        else{
            lblResturant.text = "None Availible"
            lblResturantType.text = "N/A"
            lblFoodType.text = "N/A"
            lblAddress.text = "N/A"
            let imgName = "Unavailable"
            UIResImage.image = UIImage(named:imgName)
        }
    }

    @IBAction func btnNextTouch(_ sender: Any) {
        setLabels()
    }
    
    
    @IBAction func favResturantChanged(_ sender: Any) {
        if favResturant.isOn{
            UserDefaults.standard.set(lblResturant.text, forKey: "favorite")
        }
        else{
            UserDefaults.standard.set("", forKey: "favorite")
        }
    }
    
    @IBAction func resturantMenu(_ sender: Any) {
        let app = UIApplication.shared
        let trailURL = URL(string:randomGloblaObject.menu)
        app.open(trailURL!)
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIResImage.alpha = 0.0
        lblResturant.alpha = 0.0
        lblAddress.alpha = 0.0
        lblResturantType.alpha = 0.0
        lblFoodType.alpha = 0.0
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 4.0, animations: {
            self.UIResImage.alpha = 1.0
            self.lblResturant.alpha = 1.0
            self.lblAddress.alpha = 1.0
            self.lblResturantType.alpha = 1.0
            self.lblFoodType.alpha = 1.0
        })
        setLabels()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateRestaurants()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "MealPicker2.png")!)
        
        mySound = try?
            AVAudioPlayer(contentsOf: URL(fileURLWithPath: Bundle.main.path(forResource: "counterBell", ofType: "wav")!))
    }
}
