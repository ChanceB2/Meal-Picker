//
//  Restaurants.swift
//  Meal Picker
//
//  Created by Chance Burroughs on 9/21/21.
//

import Foundation
import UIKit

class Restaurants{
    var name = ""
    var resType = ""//fast or sit down food
    var foodType = ""// American, Tex-Mex
    var address = ""
    var picture = ""
    var menu = ""
    var isFav:Bool = false
}
